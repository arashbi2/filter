Dieses Verzeichnis befindet sich immer in <ECLIPSE_HOME>.
Jedes debug launch, das pretty printing unterstützen soll, muß im Feld 'GDB command file' den Wert ../../gdb/.gdbinit stehen haben.

Damit die .gdbinit auch von Projekten gefunden wird, die sich z.B. in einem GIT repo befinden und somit noch eine Verzeichnisebene mehr haben, muß sich eine Kopie des Verzeichnisses gdb im GIT Stammverzeichnis der Eclipse installation befinden (s. Eclipse Preferences - Team - Git - Default repository folder).