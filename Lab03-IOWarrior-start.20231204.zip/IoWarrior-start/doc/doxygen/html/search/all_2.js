var searchData=
[
  ['duration_13',['duration',['../structsignal_data.html#a2c0e322db97969a7518ad0a488f3ab81',1,'signalData']]]
];
