var searchData=
[
  ['fileerrors_21',['FILEERRORS',['../class_c_sound_file.html#a90dea8d588513067959b855ff03754d2',1,'CSoundFile']]],
  ['filemodes_22',['FILEMODES',['../class_c_sound_file.html#af75d16d318375aebabf9cd30f03e44d2',1,'CSoundFile']]],
  ['fsample_23',['fSample',['../structsignal_data.html#a74824c0ded25d1e0c1b969502097dc50',1,'signalData']]]
];
