var searchData=
[
  ['gensignal_5fdualsine_24',['genSignal_DualSine',['../main_8cpp.html#a6fdae9b3ebc078ad3b1f0fab5c67697c',1,'main.cpp']]],
  ['getdataformat_25',['getDataFormat',['../class_c_sound_file.html#aef433da1f38e637f3b82d5225d6f76b3',1,'CSoundFile']]],
  ['getlasterror_26',['getLastError',['../class_c_i_o_warrior.html#a35475209571d9da931286d0b9d180ab9',1,'CIOWarrior']]],
  ['getlasterrorstr_27',['getLastErrorStr',['../class_c_i_o_warrior.html#a2ac63ecbf9d0c4ded8e312e9ccad2213',1,'CIOWarrior']]],
  ['getnumchannels_28',['getNumChannels',['../class_c_sound_file.html#a841e1b4beecda8fccf6cc9f3350e397d',1,'CSoundFile']]],
  ['getnumframes_29',['getNumFrames',['../class_c_sound_file.html#a6118e4748c121f2dcb5839f74e0a3947',1,'CSoundFile']]],
  ['getsamplerate_30',['getSampleRate',['../class_c_sound_file.html#a3ed4c7d7bf6f8508b562f519b7df9565',1,'CSoundFile']]],
  ['getstate_31',['getState',['../class_c_i_o_warrior.html#ad63e69b593f256f362e35aa68a971d89',1,'CIOWarrior']]],
  ['getstatestr_32',['getStateStr',['../class_c_i_o_warrior.html#a6f614f9042f035af664ef492bd91622c',1,'CIOWarrior']]]
];
