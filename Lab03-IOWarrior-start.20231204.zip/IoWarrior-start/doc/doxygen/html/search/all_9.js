var searchData=
[
  ['nochannels_42',['noChannels',['../structsignal_data.html#af591c8aae6cd1d3b6cfdb5dcbb586640',1,'signalData']]],
  ['noframes_43',['noFrames',['../structsignal_data.html#a6f93ed5a20efa075f6f1849d62b9ea75',1,'signalData']]]
];
