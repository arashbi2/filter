var searchData=
[
  ['fileerrors_134',['FILEERRORS',['../class_c_sound_file.html#a90dea8d588513067959b855ff03754d2',1,'CSoundFile']]],
  ['filemodes_135',['FILEMODES',['../class_c_sound_file.html#af75d16d318375aebabf9cd30f03e44d2',1,'CSoundFile']]]
];
