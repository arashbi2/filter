var searchData=
[
  ['selectsoundfile_105',['selectSoundFile',['../main_8cpp.html#aaf10d325b29c92cbd86d5e232da31f25',1,'main.cpp']]],
  ['setdataformat_106',['setDataFormat',['../class_c_sound_file.html#a9497feaeaf80e1ad933e7335ed853d73',1,'CSoundFile']]],
  ['setnumchannels_107',['setNumChannels',['../class_c_sound_file.html#af9a62b928172b110bd388c4068feaf2e',1,'CSoundFile']]],
  ['setsamplerate_108',['setSampleRate',['../class_c_sound_file.html#a49eaa041dc44e1309361db8d9c93f56d',1,'CSoundFile']]]
];
