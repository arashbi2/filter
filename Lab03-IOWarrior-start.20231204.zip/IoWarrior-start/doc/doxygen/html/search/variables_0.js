var searchData=
[
  ['bufsize_120',['bufSize',['../structsignal_data.html#a57bbe95920d7729160d5276031262ab3',1,'signalData']]]
];
