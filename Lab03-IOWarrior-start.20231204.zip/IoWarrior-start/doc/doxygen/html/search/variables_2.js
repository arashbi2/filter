var searchData=
[
  ['fsample_122',['fSample',['../structsignal_data.html#a74824c0ded25d1e0c1b969502097dc50',1,'signalData']]]
];
