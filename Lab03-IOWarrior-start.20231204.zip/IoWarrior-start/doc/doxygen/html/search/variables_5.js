var searchData=
[
  ['pbuffer_130',['pBuffer',['../structsignal_data.html#ac10b7ed72b9639cc9b039285a6cc0356',1,'signalData']]]
];
