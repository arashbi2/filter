/**
 * \file CIOWarrior.h
 *
 * \brief Interface for CIOWarrior
 * \date 05.10.21
 * \author Antje Wirth <antje.wirth@h-da.de>
 * \author Holger Frank <holger.frank@h-da.de>
 */
#ifndef CIOWARRIOR_H_
#define CIOWARRIOR_H_

#include <SKSLib.h>
#include <wtypes.h>
#include <iowkit.h>

/**
 * \brief Controller for a bare IoW40Kit device
 */
class CIOWarrior {
public:
	// todo define the enums ERRORS and STATES here (see UML class diagram)
protected:
	// todo define the attributes according to the UML class diagram here
public:
	// todo define the methods according to the UML class diagram here
protected:
	// todo define the protected method according to the UML class diagram here
};

/**
 * \brief class for IoWarrior Extension board of FBEIT
 */

#endif /* CIOWARRIOR_H_ */
