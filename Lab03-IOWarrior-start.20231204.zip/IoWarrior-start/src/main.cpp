/**
 * \file main.cpp
 * \brief main, test and auxiliary functions for ASDD Lab01
 *
 * \date 17.10.2022
 * \author A. Wirth <antje.wirth@h-da.de
 * \author H. Frank <holger.frank@h-da.de
 */

/**
 * please comment this in after you have completely defined and implemented
 * the IOWarrior class according to the UML class diagram and the descriptions
 * given in CIOWarrior.cpp
 */
// #define CIOW_COMPLETE

// header files
#include <wtypes.h>
#include <iostream>
#include <iomanip>
#include <vector>
#include <stdlib.h>
#include <conio.h>
#include <dirent.h>			// functions to scan files in directories

#define USE_MATH_DEFINES
#include <cmath>
using namespace std;

#include <SKSLib.h>
#include "CIOWarriorExt.h"
#include "CAmpMeter.h"


/**
 * horizontal divider for test list output
 */
string hDivider(80, '-');

/**
 * this structure is to keep data for a test signal
 */
typedef struct signalData {
	/**
	 * sample frequency in Hz
	 */
	long fSample;
	/**
	 * no. of channels
	 */
	int noChannels;
	/**
	 * no. of frames for total time duration of audio signal
	 */
	int noFrames;
	/**
	 * total time duration in s
	 */
	int duration;
	/**
	 * size of signal buffer
	 */
	long bufSize;
	/**
	 * pointer on signal buffer
	 */
	float *pBuffer;
} testSignal;

// ******************* auxiliary functions for tests *******************
/**
 * \brief generates a mono sawtooth signal to test the bargraph algorithm of the amplitude meter
 *
 * \param pData reference on data structure of type signalData
 */
void genSignal_Ramp(signalData& pData);

// ********* declarations of test functions (to be called in main) *********
// laboratory tasks
void Test_Lab01_IoWBase();
void Test_Lab01_IoWExtension();
void Test_Lab02_IowPlaybackControl(const string& soundfile);
void Test_Lab03_AmpMeter(testSignal sig);
void Test_Lab04_AmpMeterPlaybackIntegration(const string& soundfile);


/**
 * Main program to call test functions
 */
int main(void) {
	// set stdout in non buffered mode
	setvbuf(stdout, NULL, _IONBF, 0);
	// Set console encoding to UTF-8
	SetConsoleOutputCP(CP_UTF8);

	cout << "IOWarrior started." << endl << endl;

/**
 *  Lab Task 1 - Functional tests of CIOWarrior and CIOWarriorExt
 */
//	Test_Lab01_IoWBase();
//	Test_Lab01_IoWExtension();

/**
 * Lab Task 2 - Playback control with the IOWarrior board
 */
//	Test_Lab02_IowPlaybackControl(".\\files\\sounds\\funnysong.wav");

/**
 *  Lab Task 3 - Amplitude meter completion and integration
 */
	testSignal tstSig;
	tstSig.noChannels = 1;
	tstSig.fSample = 33;
	tstSig.duration = 1;						// total signal duration in s
	/*
	 * - generate a mono ramp from -1 ... 1
	 *
	 * the sample frequency determines only the no. of frames for the test
	 * signal in this case, i.e. the no. of calculated amplitude values for the
	 * mono signal
	 */
	genSignal_Ramp(tstSig);

//	Test_Lab03_AmpMeter(tstSig);
	delete[] tstSig.pBuffer;		// destroy signal buffer for test signal

//	Test_Lab04_AmpMeterPlaybackIntegration(".\\files\\sounds\\funnysong.wav");

	cout << endl << "IOWarrior finished." << endl << endl;
	return 0;
}

#ifdef CIOW_COMPLETE
/**
 * \brief function to perform structured unit tests for implementation of
 * IoWarrior base class CIOWarrior (i.e. IoW40 without extension)
 *
 * Tests are implemented and performed according to the test table
 * doc/UnitTests-ASDD-iowarrior.xlsx in this project
 */
void Test_Lab01_IoWBase(void) {
	cout << endl << hDivider << endl << __FUNCTION__ << " started." << endl
			<< endl;

	// global Object for waiting on pressed ENTER on keyboard in succeeding tests
	CIOConsole Ui;
	try {
		Ui.open();
	} catch (CException &e) {
		cout << e << endl;
	}

	string testNo = "1.1a/b";
	cout << "Test " << testNo << " started" << endl;
	try {
		CIOWarrior DuT;
		DuT.open();
		cout << "Test " << testNo << " finished" << endl;
	} catch (CException &e) {
		cout << e << endl;
		cout << "Test suite " << __FUNCTION__ << " aborted" << endl;
		return;			// abort test suite if exception occours
	}

	testNo = "1.2";
	cout << hDivider << endl << "Test " << testNo << " started" << endl;
	try {
		CIOWarrior DuT;
		DuT.printState();
		cout << "State: " << DuT.getState() << " / " << DuT.getStateStr()
				<< endl << "Last Error: " << DuT.getLastError() << " / "
				<< DuT.getLastErrorStr() << endl;
		cout << "Test " << testNo << " finished" << endl;
	} catch (CException &e) {
		cout << e << endl;
		cout << "Test " << testNo << " aborted" << endl;
	}

	testNo = "1.3";
	cout << hDivider << endl << "Test " << testNo << " started" << endl;
	try {
		CIOWarrior DuT;
		DuT.open();
		DuT.printState();
		cout << "State: " << DuT.getState() << " / " << DuT.getStateStr()
				<< endl << "Last Error: " << DuT.getLastError() << " / "
				<< DuT.getLastErrorStr() << endl;
		cout << "Test " << testNo << " finished" << endl;
	} catch (CException &e) {
		cout << e << endl;
		cout << "Test " << testNo << " aborted" << endl;
	}

	testNo = "1.4";
	cout << hDivider << endl << "Test " << testNo << " started" << endl;
	try {
		CIOWarrior DuT;
		DuT.writeLEDs(0xaa);
		cout << "Test " << testNo << " finished" << endl;
	} catch (CException &e) {
		cout << e << endl;
		cout << "Test " << testNo << " aborted" << endl;
	}

	testNo = "1.5";
	cout << hDivider << endl << "Test " << testNo << " started" << endl;
	try {
		CIOWarrior DuT;
		DuT.open();
		DuT.writeLEDs(0xaa);
		cout << "press ENTER to proceed" << endl;
		while (!Ui.keyPressed())
			;
		cout << "Test " << testNo << " finished" << endl;
	} catch (CException &e) {
		cout << e << endl;
		cout << "Test " << testNo << " aborted" << endl;
	}

	testNo = "1.6";
	cout << hDivider << endl << "Test " << testNo << " started" << endl;
	try {
		CIOWarrior DuT;
		cout << DuT.keyPressed() << endl;
		cout << "Test " << testNo << " finished" << endl;
	} catch (CException &e) {
		cout << e << endl;
		cout << "Test " << testNo << " aborted" << endl;
	}

	testNo = "1.7";
	cout << hDivider << endl << "Test " << testNo << " started" << endl;
	try {
		CIOWarrior DuT;
		DuT.open();
		cout << "press ENTER to end test " << testNo << endl;
		while (!Ui.keyPressed()) {
			cout << DuT.keyPressed() << endl;
			Sleep(500);
		}
		cout << "Test " << testNo << " finished" << endl;
	} catch (CException &e) {
		cout << e << endl;
		cout << "Test " << testNo << " aborted" << endl;
	}

	cout << endl << __FUNCTION__ << " finished." << endl << hDivider << endl;
}

/**
 * \brief function to perform structured unit tests for implementation of
 * IoWarrior extension class CIOWarriorExt (i.e. IoW40 plus extension)
 *
 * Tests are implemented and performed according to the test table
 * doc/UnitTests-ASDD-iowarrior.xlsx in this project
 */
void Test_Lab01_IoWExtension(void) {

	cout << endl << hDivider << endl << __FUNCTION__ << " started." << endl
			<< endl;

	string testNo = "2.1a/b/c";
	cout << "Test " << testNo << " started" << endl;


	// global Object for waiting for pressed ENTER on keyboard in succeeding tests
	CIOConsole Ui;

	try {
		Ui.open();
	} catch (CException &e) {
		cout << e << endl;
	}

	try {
		CIOWarriorExt DuT;
		DuT.open();
	} catch (CException &e) {
		cout << e << endl;
		cout << "Test suite " << __FUNCTION__ << " aborted" << endl;
		return;			// abort test suite if exception occours
	}

	cout << "Test " << testNo << " finished" << endl;

	testNo = "2.2";
	cout << hDivider << endl << "Test " << testNo << " started" << endl;
	try {
		CIOWarriorExt DuT;
		DuT.open();
		DuT.printDeviceInfo();
		DuT.printState();
		cout << "Test " << testNo << " finished" << endl;
	} catch (CException &e) {
		cout << e << endl;
		cout << "Test " << testNo << " aborted" << endl;
	}

	testNo = "2.3";
	cout << hDivider << endl << "Test " << testNo << " started" << endl;
	try {
		CIOWarriorExt DuT;
		DuT.writeLEDs(0xaa55);
		cout << "Test " << testNo << " finished" << endl;
	} catch (CException &e) {
		cout << e << endl;
		cout << "Test " << testNo << " aborted" << endl;
	}

	testNo = "2.4";
	cout << hDivider << endl << "Test " << testNo << " started" << endl;
	try {
		CIOWarriorExt DuT;
		DuT.open();
		DuT.writeLEDs(0xaaaa);
		cout << "press ENTER to proceed" << endl;
		while (!Ui.keyPressed())
			;
		DuT.writeLEDs(0x5555);
		cout << "press ENTER to proceed" << endl;
		while (!Ui.keyPressed())
			;
		cout << "Test " << testNo << " finished" << endl;
	} catch (CException &e) {
		cout << e << endl;
		cout << "Test " << testNo << " aborted" << endl;
	}

	testNo = "2.5";
	cout << hDivider << endl << "Test " << testNo << " started" << endl;
	try {
		CIOWarriorExt DuT;
		DuT.readButtons();
		cout << "Test " << testNo << " finished" << endl;
	} catch (CException &e) {
		cout << e << endl;
		cout << "Test " << testNo << " aborted" << endl;
	}

	testNo = "2.6";
	cout << hDivider << endl << "Test " << testNo << " started" << endl;
	try {
		CIOWarriorExt DuT;
		DuT.open();
		cout << "press ENTER to end test" << endl;
		while (!Ui.keyPressed()) {
			cout << (bitset<6> ) DuT.readButtons() << endl;
			Sleep(500);
		}
		cout << "Test " << testNo << " finished" << endl;
	} catch (CException &e) {
		cout << e << endl;
		cout << "Test " << testNo << " aborted" << endl;
	}

	testNo = "2.7";
	cout << hDivider << endl << "Test " << testNo << " started" << endl;
	try {
		CIOWarriorExt DuT;
		DuT.open();
		cout << "press ENTER to end test" << endl;
		while (!Ui.keyPressed()) {
			cout
					<< (bitset<6> ) DuT.readButtons(
							CIOWarriorExt::BTN_1 | CIOWarriorExt::BTN_3)
					<< endl;
			Sleep(500);
		}
		cout << "Test " << testNo << " finished" << endl;
	} catch (CException &e) {
		cout << e << endl;
		cout << "Test " << testNo << " aborted" << endl;
	}

	cout << endl << __FUNCTION__ << " finished." << endl << hDivider << endl;
}

/**
 * \brief Test program for sound file play back with start/stop resp. pause/resume using the
 *  button on the IOWarrior board (connected to port 0 pin 0)
 *
 * \param soundfile name of soundfile incl. path
 */
void Test_Lab02_IowPlaybackControl(const string &soundfile) {
	cout << endl << hDivider << endl << __FUNCTION__ << " started." << endl
			<< endl;

	// todo insert your implementation of lab 01 task 2 here (Test_Lab02_AudioPlayer()) and modify it

	cout << endl << __FUNCTION__ << " finished." << endl << hDivider << endl;
}

/**
 * \brief test program to check the pattern generation of the amplitude meter
 *
 * \param sig a structure with a test signal that shall be visualized
 */
void Test_Lab03_AmpMeter(testSignal sig) {
	cout << endl << __FUNCTION__ << " started." << endl << hDivider << endl;

	try {
		CIOWarriorExt IoC;			// IOCOntroller (IOWarrior)
		CAmpMeter meter;
		IoC.open();

// linear scaling test
		meter.init(&IoC, CAmpMeter::SCALING_MODE_LIN, 0, 1);
// logarithmic scaling test
//		meter.init(&IoC, CAmpMeter::SCALING_MODE_LOG, 0, 1, -30);

		// test with single value
		for (uint8_t idx = 0; idx < sig.bufSize; idx++) {
			meter.write(sig.pBuffer[idx]);
			cout << (int) idx << " : " << sig.pBuffer[idx] << endl;
			Sleep(1000);
		}
		IoC.close();
	} catch (CException &e) {
		cout << e << endl;
	}

	cout << endl << __FUNCTION__ << " finished." << endl << hDivider << endl;
}

/**
 * \brief integration of AmpMeter into Audio Player
 * \param soundfile soundfile to be played
 */
void Test_Lab04_AmpMeterPlaybackIntegration(const string &soundfile) {
	cout << endl << __FUNCTION__ << " started." << endl << hDivider << endl;

	// todo insert implementation of lab task 4 here

	cout << endl << __FUNCTION__ << " finished." << endl << hDivider << endl;
}
#endif /* CIOW_COMPLETE */

/*
 * generates test signal for AmpMeter test
 * - calculates number of samples
 * - calculates total buffer size
 * - creates signal buffer
 * - fills buffer with signal
 */
void genSignal_Ramp(signalData &pData) {
	pData.noChannels = 1;
	pData.bufSize = pData.noChannels * pData.fSample * pData.duration; // total no of samples
	pData.pBuffer = new float[pData.bufSize]; // create audio buffer for output

	// float type samples value range -1 ... 1
	for (uint16_t sampleIdx = 0; sampleIdx < pData.bufSize;
			sampleIdx += pData.noChannels) {
		pData.pBuffer[sampleIdx] = -1. + 2 * (float) sampleIdx / pData.bufSize;
	}
}
