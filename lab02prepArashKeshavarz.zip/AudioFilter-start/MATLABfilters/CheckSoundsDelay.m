close all; clc;clear all
%% check the delay filter
% enter the name of the sound you used in C++ here
sndname='hey';
[xk,fs]= audioread(['..\files\sounds\' sndname '.wav']);
[ck]= audioread(['..\files\filtered_sounds\' sndname '_filtered.wav']);

%% create and apply the MATLAB delay filter
% change the parameters to adopt them to your C++ program
%
% delay time in ms;feedforward gain;feedback gain
tdelay=250e-3; gFF=0.5; gFB=0;      % basic_delay_16000_Order4001
%tdelay=50e-3; gFF=0.5; gFB=0.75;    % basic_delay_feedback_16000_Order801
%tdelay=500e-3; gFF=0.5; gFB=0.75;   % basic_delay_feedback_16000_Order8001

[b,a]=createBasicDelayFilters(gFF,gFB,tdelay,fs);
mk=filter(b,a,xk);  % filter the signal

%% plot to compare the filtered signals 
tck=(0:length(ck)-1)/fs;    % time vector for the C++ filtered signal
tmk=(0:length(mk)-1)/fs;    % time vector for the Matlab filtered signal

[m,n]=size(ck);
if(n==2)            % stereo
    % compare left channels
    subplot(2,1,1)
    plot(tck,ck(:,1),tmk,mk(:,1))
    legend('ck - filtered by C++','mk - filtered by MATLAB')
    xlabel('t/s')
    title('Left channel')
    % compare right channels
    subplot(2,1,2)
    plot(tck,ck(:,2),tmk,mk(:,2))
    legend('ck - filtered by C++','y1k - filtered by MATLAB')
    xlabel('t/s')
    title('Right channel')
elseif(n==1)           % mono
    plot(tck,ck(:,1),tmk,mk(:,1))
    legend('ck - filtered by C++','mk - filtered by MATLAB')
    xlabel('t/s')
    title('Mono signal')
end

% compare signals by playing
disp({'(1) original','(2) C++ filtered' '(3) MATLAB filtered'}')
plObj=audioplayer([xk;ck;mk],fs);
playblocking(plObj);
