close all; clc;clear all
[xk,fs]= audioread('..\files\sounds\hey.wav');
fs_designs=[11025 16000 22050 44100 48000];
fs_designs=fs_designs(fs~=fs_designs);
play=1;

%% Butterworth filter design
ftype='lowpass';
fc=2000;            % cutoff frequency
N=6;                % filter order
plotfilter=1;       % plot amplitude response on

[b, a] = createButterFilter(N,fs,fc,ftype,plotfilter); % filter coefficients
% write the filter coefficients
filename=writeFilterDataFileHeader("..\files\filters\"+num2str(fc)+"Hz_",ftype,N,"cutoff frequency fc="+num2str(fc));
writeFilterData(filename,fs,b,a);

[yk]=filter(b,a,xk);
if play==1
    plObj=audioplayer([xk;yk],fs);
    playblocking(plObj);
end

% plot magnitude and spectrum
hold all
Yf=fft(yk);
Xf=fft(xk);
f=0:fs/length(xk):fs/2;
semilogx(f,20*log10(abs(Xf(1:length(f)))),f,20*log10(abs(Yf(1:length(f)))))
legend('filter magnitude','original','low pass filtered')
xlim([min(f) max(f)])

% designs for other sampling frequencies
plotfilter=0;       % plot amplitude response off
for k=1:length(fs_designs)
    [b,a] = createButterFilter(N,fs_designs(k),fc,ftype,plotfilter); % filter coefficients
    writeFilterData(filename,fs_designs(k),b,a);  % write the filter coefficients
end

%% Filters with a free amplitude response
% treble boost (shelving filter)
figure
plotfilter=1;       % plot amplitude response on
[b,a,order,flin] = createYulewalkFilters(fs,plotfilter); 
% write the filter coefficients
filename=writeFilterDataFileHeader("..\files\filters\yulewalk_","treble_boost",order,"boosting starts at < "+ num2str(flin) +" and goes upto the half sampling frequency");
writeFilterData(filename,fs,b,a);

% Test filter
[yk1]=filter(b,a,xk);
if play==1
    plObj=audioplayer([xk;yk1],fs);
    playblocking(plObj);
end

% spectrum
Yf=fft(yk1);                % filtered signal
Xf=fft(xk);                 % original signal
ffft=0:fs/length(xk):fs/2;    % appropriate frequency vector
% plots
hold all
semilogx(ffft,20*log10(abs(Yf(1:length(ffft)))),ffft,20*log10(abs(Xf(1:length(ffft)))))
xlabel('frequency in Hz')
ylabel('Magnitude in dB')
legend('Yule-Walker filter magnitude','ideal filter magnitude','trebel boosted','original')
grid

% designs for other sampling frequencies
plotfilter=0;       % plot amplitude response off
for k=1:length(fs_designs)
    [b,a] = createYulewalkFilters(fs_designs(k),plotfilter); % filter coefficients
    writeFilterData(filename,fs_designs(k),b,a);  % write the filter coefficients
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% delay effects
% basic delay
tdelay=250e-3;      % delay time in ms
gFF=0.5;            % feedforward gain
[b,a]=createBasicDelayFilters(gFF,0,tdelay,fs);

% test filter
if play==1
    [yk1]=filter(b,a,xk);
    plObj=audioplayer([xk;yk1/max(max(abs(yk1)))],fs);
    playblocking(plObj);
end

% designs for other sampling frequencies
for k=1:length(fs_designs)
    createBasicDelayFilters(gFF,0,tdelay,fs_designs(k));
end

%% basic delay with feedback
tdelay=50e-3;      % delay time in ms
gFF=0.5;           % feedforward gain
gFB=0.75;           % feedback gain
[b,a]=createBasicDelayFilters(gFF,gFB,tdelay,fs);

% playing
if play==1
    [yk1]=filter(b,a,xk);
    plObj=audioplayer([xk;yk1/max(max(abs(yk1)))],fs);
    playblocking(plObj);
end

% designs for other sampling frequencies
for k=1:length(fs_designs)
    createBasicDelayFilters(gFF,gFB,tdelay,fs_designs(k));
end

%% delay filters of very high order
tdelay=500e-3;
gFB=0.75;
gFF=0.5;
createBasicDelayFilters(gFF,gFB,tdelay,48000);
createBasicDelayFilters(gFF,gFB,tdelay,44100);
createBasicDelayFilters(gFF,gFB,tdelay,22050);
createBasicDelayFilters(gFF,gFB,tdelay,16000);
createBasicDelayFilters(gFF,gFB,tdelay,11025);

