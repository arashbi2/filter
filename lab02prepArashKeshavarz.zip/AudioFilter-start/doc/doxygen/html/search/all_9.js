var searchData=
[
  ['setsamplerate_23',['setSampleRate',['../class_c_sound_file.html#a49eaa041dc44e1309361db8d9c93f56d',1,'CSoundFile']]]
];
