var searchData=
[
  ['write_27',['write',['../class_c_sound_file.html#a8dab56a888851b8f240a68abc7688a1a',1,'CSoundFile']]]
];
