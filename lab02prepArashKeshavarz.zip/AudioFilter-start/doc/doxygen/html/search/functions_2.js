var searchData=
[
  ['geterrortxt_45',['getErrorTxt',['../class_c_file_base.html#a5f77c16efd7cf38103d28d2df17975a6',1,'CFileBase']]],
  ['getfilter_46',['getFilter',['../main_8cpp.html#a7a742a8213f4614439384650e583c130',1,'main.cpp']]],
  ['getnumframes_47',['getNumFrames',['../class_c_sound_file.html#a6118e4748c121f2dcb5839f74e0a3947',1,'CSoundFile']]]
];
