var searchData=
[
  ['isfilew_49',['isFileW',['../class_c_file_base.html#ad6cf1e2eb156b9dc3d27a5ee3d1f2b85',1,'CFileBase']]]
];
