var searchData=
[
  ['open_50',['open',['../class_c_sound_file.html#a458c56274d9f1a2ad90313fc1a295105',1,'CSoundFile']]]
];
