var searchData=
[
  ['read_53',['read',['../class_c_sound_file.html#a7b84d19109a4d20e41ce83b39d4c31bc',1,'CSoundFile']]],
  ['reset_54',['reset',['../class_c_filter_base.html#a331b23455d62cf03488623be81c228be',1,'CFilterBase']]]
];
