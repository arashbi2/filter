var searchData=
[
  ['m_5fchannels_63',['m_channels',['../class_c_filter_base.html#a814cc6adce0ddd9fbe4bb8424763c5bd',1,'CFilterBase']]],
  ['m_5forder_64',['m_order',['../class_c_filter_base.html#ae2185d565f7a47173e700353f72d7159',1,'CFilterBase']]],
  ['m_5fz_65',['m_z',['../class_c_filter_base.html#a928a5944049acecbb9a0a1dce07094ae',1,'CFilterBase']]]
];
