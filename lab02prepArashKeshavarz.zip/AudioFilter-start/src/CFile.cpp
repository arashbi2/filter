/*
 * File.cpp
 *
 *  Created on: 14.11.2019
 *      Author: A. Wirth
 */
#include <iostream>
#include <stdio.h>
#include <string.h>
#include <iomanip>
using namespace std;

#include <SKSLib.h>
#include "CFile.h"

/**
 * Constructor
 */
CFileBase::CFileBase(string path, unsigned int mode) {
	m_path = path;
	if ((mode != FILE_READ) && (mode != FILE_WRITE)
			&& (mode != FILE_WRITEAPPEND))
		mode = FILE_MODEUNKNOWN;
	if (mode == FILE_MODEUNKNOWN)
		m_mode = FILE_READ | FILE_WRITEAPPEND; // allow all operations
	else
		m_mode = mode;
}

CFileBase::~CFileBase() {
	cout << "CFileBase destructor" << endl;
}

void CFileBase::print(void) {
	cout << "CFileBase[" << getModeTxt() << "]: " << m_path << endl;
}

/**
 * utility methods to get the open mode
 */
bool CFileBase::isFileW() {
	if ((m_mode & FILE_WRITE) == 0)
		return false;
	return true;
}

bool CFileBase::isFileR() {
	if ((m_mode & FILE_READ) == 0)
		return false;
	return true;
}

bool CFileBase::isFileWA() {
	if ((m_mode & FILE_WRITEAPPEND) == 0)
		return false;
	return true;
}

string CFileBase::getErrorTxt(FILEERRORS err) {
	switch (err) {
	case FILE_E_UNKNOWNOPENMODE:
		return string("unknown file open mode");
	case FILE_E_NOFILE:
		return string("file not found");
	case FILE_E_FILENOTOPEN:
		return string("file not open");
	case FILE_E_NOBUFFER:
		return string("no data buffer available");
	case FILE_E_CANTREAD:
		return string("file has been opened in write only mode");
	case FILE_E_READ:
		return string("error during read");
	case FILE_E_CANTWRITE:
		return string("file has been opened in read only mode");
	case FILE_E_WRITE:
		return string("error during write");
	case FILE_E_SPECIAL:
		return string("file error: ");
	default:
		return string("unknown error");
	}
}

// here, we may have a combination of different modes
string CFileBase::getModeTxt() {
	string sret;
	if (m_mode & FILE_READ)
		sret += "read mode";
	if (m_mode & FILE_WRITE) {
		if (sret.empty())
			sret = "write mode";
		else
			sret += " & write mode";
	}
	if (m_mode & FILE_WRITEAPPEND) {
		if (sret.empty())
			sret = "write/append mode";
		else
			sret += " & write/append mode";
	}
	if (sret.empty())
		sret = "unknown mode";
	return sret;
}

CSoundFile::CSoundFile(string path, const FILEMODES mode) :
		CFileBase(path, mode) {
	memset(&m_sfinfo, 0, sizeof(m_sfinfo));
	m_pSFile = NULL;
	cout << "CSoundFile constructor" << endl;
}

CSoundFile::~CSoundFile() {
	close();
	cout << "CSoundFile destructor" << endl;
}

/**
 * overloaded method
 */
void CSoundFile::print(void) {
	CFileBase::print();
	cout << "CSoundFile[" << hex << m_pSFile << dec << "]" << endl;
	cout << "Soundfile: channels(" << m_sfinfo.channels << ") frames("
			<< m_sfinfo.frames;
	cout << ") fs(" << m_sfinfo.samplerate / 1000. << "kHz)" << endl;
	cout << "Duration: " << m_sfinfo.frames / m_sfinfo.samplerate << "s"
			<< endl;
}

void CSoundFile::open() {
	int mode;
	if (isFileR() && (isFileWA() || isFileW()))
		mode = SFM_RDWR;
	else if (isFileW() || isFileWA())
		mode = SFM_WRITE;
	else if (isFileR())
		mode = SFM_READ;
	else
		throw CException(CException::SRC_File, FILE_E_UNKNOWNOPENMODE,
				getErrorTxt(FILE_E_UNKNOWNOPENMODE));

	m_pSFile = sf_open(m_path.c_str(), mode, &m_sfinfo);
	if (!m_pSFile)
		throw CException(CException::SRC_File, sf_error(m_pSFile),
				m_path + ": " + sf_strerror(m_pSFile));

	// apply clipping when file has been opened for write (avoids faulty samples)
	if((mode == SFM_RDWR) || (mode == SFM_WRITE))
		sf_command (m_pSFile, SFC_SET_CLIPPING, NULL, SF_TRUE);
}

void CSoundFile::close() {
	if (m_pSFile != NULL) {
		sf_close(m_pSFile);
		m_pSFile = NULL;
	}
}

int CSoundFile::read(float *buf, int bufsize) {
	if (m_pSFile == NULL)
		throw CException(CException::SRC_File, FILE_E_FILENOTOPEN,
				getErrorTxt(FILE_E_FILENOTOPEN));
	if (buf == NULL)
		throw CException(CException::SRC_File, FILE_E_NOBUFFER,
				getErrorTxt(FILE_E_NOBUFFER));
	if(!isFileR())
		throw CException(CException::SRC_File, FILE_E_CANTREAD,
				getErrorTxt(FILE_E_CANTREAD));

	int szread = sf_read_float(m_pSFile, buf, bufsize);
	// returns 0 if no data left to read
	return szread;
}

void CSoundFile::write(float *buf, int bufsize) {
	if (m_pSFile == NULL)
		throw CException(CException::SRC_File, FILE_E_FILENOTOPEN,
				getErrorTxt(FILE_E_FILENOTOPEN));
	if (buf == NULL)
		throw CException(CException::SRC_File, FILE_E_NOBUFFER,
				getErrorTxt(FILE_E_NOBUFFER));
	if(!(isFileW()||isFileWA()))
		throw CException(CException::SRC_File, FILE_E_CANTWRITE,
				getErrorTxt(FILE_E_CANTWRITE));

	int szwrite = sf_write_float(m_pSFile, buf, bufsize);
	if (szwrite != bufsize) {
		close();
		throw CException(CException::SRC_File, FILE_E_WRITE,
				getErrorTxt(FILE_E_WRITE));
	}
}

int CSoundFile::getNumFrames() {
	return m_sfinfo.frames;
}

int CSoundFile::getSampleRate() {
	return m_sfinfo.samplerate;
}

int CSoundFile::getFormat() {
	return m_sfinfo.format;
}

int CSoundFile::getNumChannels() {
	return m_sfinfo.channels;
}

void CSoundFile::setSampleRate(int fs) {
	if (fs <= 0)
		throw CException(CException::SRC_File, -1,
				"Invalid sample rate (must be > 0)!");
	m_sfinfo.samplerate = fs;
}

void CSoundFile::setNumChannels(int numChan) {
	if (numChan <= 0)
		throw CException(CException::SRC_File, -1,
				"Invalid number of channels (must be > 0)!");
	m_sfinfo.channels = numChan;
}

void CSoundFile::setFormat(int format) {
	m_sfinfo.format = format;
}

CFilterFile::CFilterFile(string path, const FILEMODES mode):CFileBase(path, mode)   {
	cout<<"CFilterFile constructor"<<endl;
}

CFilterFile::~CFilterFile() {
	cout << "CFilterFile destructor" << endl;
}

string CFilterFile::getinfo()
{
	return m_filterinfo;
	//cout<<"m_filterinfo "<<m_filterinfo<<"\n";
}


int CFilterFile::getOrder()
{
	return m_order;
	//cout<<"m_order "<<m_order<<"\n";
}


float* CFilterFile::geta()
{
	return m_a;
}

float* CFilterFile::getb()
{
	return m_b;
}


int CFilterFile::getalen()
{
	return m_alen;
}

int CFilterFile::getblen()
{
	return m_blen;
}

int CFilterFile::getfs()
{
	return m_fs;
}


void CFilterFile::print()
{
	cout << endl << "header: type=" << m_filtertype << " Order=" << m_order << " Info="
			<< m_filterinfo << endl;

	cout << "fs=" << m_fs << endl;
	if ((m_a != NULL) && (m_b != NULL)) {
		cout << "b= " << fixed << setprecision(8);
		for (int i = 0; i < m_blen; i++)
			cout << m_b[i] << "\t";
		cout << endl << "a= ";
		for (int i = 0; i < m_alen; i++)
			cout << m_a[i] << "\t";
		cout << endl;
		delete[] m_b;
		delete[] m_a;
	} else
		cout << "No coefficients found for fs!" << endl;
}


string CFilterFile::gettype()
{
	return m_filtertype;
	//cout<<"m_filtertype "<<m_filtertype<<"\n";
}


int CFilterFile::read(int fs)
{

	if (m_pFile == NULL)
			return false;

		fseek(m_pFile, 0, SEEK_SET);	// ensure to start at the beginning of the file

		// get the header
		int sbufsize = 360;
		char sbuf[sbufsize];
		fgets(sbuf, sbufsize, m_pFile);

		// parse the header
		string s = sbuf;
		m_order = 0;	// order (number)
		int pos = 0, end = 0;
		end = s.find(";", pos);
		m_filtertype = s.substr(pos, end - pos);
		pos = end + 1;
		end = s.find(";", pos);
		string sorder = s.substr(pos, end - pos);
		m_order = stoi(sorder);
		m_filterinfo = s.substr(end + 1);

		// read data
		int i, fsr;
		while ( NULL != fgets(sbuf, sbufsize, m_pFile)) {
			fsr = stoi(sbuf);			// find fs
			m_fs=fs;
			if (fs != fsr) {
				char *pgot = sbuf;
				while (pgot)			// skip b coefficients
				{
					pgot = fgets(sbuf, sbufsize, m_pFile);
					if (NULL != strrchr(sbuf, '\n'))
						break; // end of line has been read
				}
				while (pgot)	// skip a coefficients
				{
					pgot = fgets(sbuf, sbufsize, m_pFile);
					if (NULL != strrchr(sbuf, '\n'))
						break;
				}
			} else {
				m_b = new float[m_order + 1];
				m_a = new float[m_order + 1];
				char sep;
				for (i = 0; i < m_order + 1; i++) {
					if (EOF == fscanf(m_pFile, "%f%c", &m_b[i], &sep))
						break;
					if (sep == '\n')
						break;
				}
				m_blen = i;
				if (sep != '\n')
					fscanf(m_pFile, "%c", &sep);
				for (i = 0; i < m_order + 1; i++) {
					if (EOF == fscanf(m_pFile, "%f%c", &m_a[i], &sep))
						break;
					if (sep == '\n')
						break;
				}
				m_alen = i;
				if (sep != '\n')
					fscanf(m_pFile, "%c", &sep);
				return 1;
			}
		}
		return 0;
}

void CFilterFile::open()
{
	if(isFileR())
	{
		m_pFile=fopen(m_path.c_str(),"r");
		cout<<"file opened\n";
		if(m_pFile==NULL)
		{
			cout<<"file not found\n";
			return;
		}
	}
	else
		throw CException(CException::SRC_File, FILE_E_UNKNOWNOPENMODE,
				getErrorTxt(FILE_E_UNKNOWNOPENMODE));
}


void CFilterFile::close()
{
	if(m_pFile!=NULL)
	{
		fclose(m_pFile);
		cout<<"file closed\n";
		m_pFile=nullptr;
	}
	else
		cout<<"file cannot be closed\n";

}


