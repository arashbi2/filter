/**
 * \file File.h
 *
 * header file for file classes
 *
 * \see File
 */
#ifndef FILE_H_
#define FILE_H_

#include "sndfile.h"
#include <string>
using namespace std;

/**
 * base class for files contains common properties and common behavior for
 * all files
 */

class CFileBase {
public:
	enum FILEMODES {
		FILE_MODEUNKNOWN = 0x00,
		FILE_READ = 0x01,
		FILE_WRITE = 0x02,
		FILE_WRITEAPPEND = 0x04
	};
	enum FILEERRORS {
		FILE_E_UNKNOWNOPENMODE,
		FILE_E_NOFILE,
		FILE_E_FILENOTOPEN,
		FILE_E_NOBUFFER,
		FILE_E_READ,
		FILE_E_CANTREAD,
		FILE_E_CANTWRITE,
		FILE_E_WRITE,
		FILE_E_SPECIAL
	};

private:
	unsigned int m_mode;	// file mode

protected:
	string m_path;			// complete file path

public:
	CFileBase(string path, unsigned int mode = FILE_MODEUNKNOWN);
	virtual ~CFileBase();

	/**
	 * prints content of the file on console
	 */
	virtual void print(void);

protected:
	/**
	 * Methods for the retrieval of file mode
	 */
	bool isFileW();
	bool isFileR();
	bool isFileWA();
	/**
	 * Methods for conversion of enum values into text
	 */
	string getErrorTxt(FILEERRORS err);
	string getModeTxt();
};

/**
 * Soundfile handling class
 *
 */
class CSoundFile: public CFileBase {
private:
	SNDFILE *m_pSFile;
	SF_INFO m_sfinfo;

public:
	CSoundFile(string path, const FILEMODES mode);
	~CSoundFile();

	/**
	 * opens a sound file
	 */
	void open();
	/**
	 * closes a sound file
	 */
	void close();
	/**
	 *\brief  reads the content of the sound file
	 *\brief  returns the total number of samples (not frames!) read
	 *\params buf[in] - address of a buffer to store floating point audio data
	 *\params bufsize[in] - size of the buffer in floating point elements
	 */
	int read(float *buf, int bufsize);
	/**
	 * writes the content of the sound file
	 */
	void write(float *buf, int bufsize);
	/**
	 * prints the properties of the sound file on the console
	 */
	void print(void);
	/**
	 * methods to retrieve information about the sound file
	 */
	int getNumFrames();
	int getSampleRate();
	int getNumChannels();
	int getFormat();

	/**
	 * methods to set information about the sound file (for writing)
	 */
	void setSampleRate(int fs);
	void setNumChannels(int numChan);
	void setFormat(int format);
};
class CFilterFile: public CFileBase {
private:

	/**
	 * \brief filter coefficients of numerator
	 */
	float *m_b;
	/**
	 * \brief filter coefficients of denominator
	 */
	float *m_a;
	int m_alen;
	int m_blen;
	int m_order;
	int m_fs;
	int m_channels;
	string m_filtertype;
	string m_filterinfo;
	FILE* m_pFile=NULL;


public:
	/**
	 * \brief Constructor
	 *
	 * - dynamic creation of arrays for filter coefficients
	 * - initialization of arrays
	 * - throws exception if order or channels are zero
	 *
	 * \param ca pointer to array of denominator filter coefficients
	 * \param cb pointer to array of numerator filter coefficients
	 * \param order filter order
	 * \param channels number of channels of original signal
	 */
	CFilterFile(string path,const FILEMODES mode);
	void open();
	void close();
	int read(int fs);
	void print();
	int getOrder();
	int getalen();
	int getblen();
	int getfs();
	string getinfo();
	string gettype();
	float* geta();
	float* getb();


	/**
	 * \brief deletes filter coefficient arrays
	 */
	virtual ~CFilterFile();





	//bool filter(float *x, float *y, int framesPerBuffer); // straight forward difference equation

};

#endif /* FILE_H_ */
