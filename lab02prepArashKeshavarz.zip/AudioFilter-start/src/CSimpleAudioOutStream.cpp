/*
 * CSimpleAudioOutStream.cpp
 *
 *  Created on: Nov 27, 2023
 *      Author: Arash Keshavarz Taromsari
 */
#include <iostream>
#include <stdio.h>
#include "SKSLib.h"
using namespace std;
#include "portaudio.h"
#include "CFile.h"
#include "CSimpleAudioOutStream.h"
#include "CException.h"
#include <cstddef>

CSimpleAudioOutStream::CSimpleAudioOutStream() {
	m_stream=NULL;
	m_numObj++;
	m_state=NOTREADY;
	// TODO Auto-generated constructor stub

}

CSimpleAudioOutStream::~CSimpleAudioOutStream() {
	m_numObj--;
	// TODO Auto-generated destructor stub
}

void CSimpleAudioOutStream::stop() {
	if(m_state==PLAYING) // this is an error
		{
			PaError err=Pa_StopStream(m_stream);
			if(err==paNoError)
			{
				cout<<"stopped stream\n";
				m_state=READY;
			}
			else
				cout<<"unable to stop stream\n";
		}
		else
		{
			CException myException(CException::SRC_SimpleAudioDevice, -1, "File cannot be stopped!\n");
			throw(myException);
		}
}

void CSimpleAudioOutStream::play(float *pBlock,int framesPerBlock) {
	//sf1.open();
	PaError err;
	if(m_state!=PLAYING)
	{
		CException myException(CException::SRC_SimpleAudioDevice, -1, "File cannot be played!\n");
		throw(myException);
	}
	err=Pa_WriteStream(m_stream, pBlock, framesPerBlock);
	if(err==paNoError)
	{
		cout<<"play successful \n";
		m_state=PLAYING;
	}
	else
	{
		CException myException(CException::SRC_SimpleAudioDevice, -1, " File not able to play!\n");
		throw(myException);
	}
}



void CSimpleAudioOutStream::pause() {
	if(m_state==PLAYING) // this is an error
		{
			PaError err=Pa_StopStream(m_stream);
			if(err==paNoError)
			{
				cout<<"paused stream\n";
				m_state=READY;
			}
			else
				cout<<"unable to pause stream\n";
		}
		else
		{
			CException myException(CException::SRC_SimpleAudioDevice, -1, "File cannot be paused!\n");
			throw(myException);
		}
}


void CSimpleAudioOutStream::open(int numChan, double fSample,unsigned long framesPerBuffer) {
	// check the state of the object
	if(m_state != NOTREADY) // we have nothing to do, because the object has already been opened successfully
		return;
	else
	{
		PaError err,err1;
		PaStreamParameters outputParameters;
		err = Pa_Initialize();
		if(err==paNoError)
		{
			outputParameters.device = Pa_GetDefaultOutputDevice(); /* default output device */
			if (outputParameters.device != paNoDevice)
			{
				outputParameters.channelCount = numChan;
				outputParameters.sampleFormat = paFloat32;  //32 bit floating point output
				outputParameters.suggestedLatency = Pa_GetDeviceInfo( outputParameters.device )->defaultHighOutputLatency;
				outputParameters.hostApiSpecificStreamInfo = NULL;
				err1=Pa_OpenStream(&m_stream, NULL,  &outputParameters, fSample, framesPerBuffer, paClipOff, NULL,  NULL );
				if(err1==paNoError)
				{
					m_state=READY;
					cout<<"opened,ready to get started\n";
				}
				else
					throw(CException(CException::SRC_SimpleAudioDevice,err1,Pa_GetErrorText(err1)));
			}
			else
				cout<<"not able to find output devices\n";
		}
		else
			cout<<"not able to initialize\n";
	}
}


void CSimpleAudioOutStream::resume() {
	// check the state of the object
	if(m_state==NOTREADY) // this is an error
	{
		CException myException(CException::SRC_SimpleAudioDevice, -1, "File not opened!\n");
		throw(myException);
	}
	else if(m_state==PLAYING)
		return;
	// now we can handle the READY state
	PaError err=Pa_StartStream(m_stream);
	//PaError err1= Pa_IsStreamActive	(m_stream);
	if(err==paNoError)
	{
		cout<<"resumed\n";
		m_state=PLAYING;
	}
	else
	{
		CException myException(CException::SRC_SimpleAudioDevice, -1, "File not resumed!\n");
		throw(myException);
	}

	/*if( err == paNoError)
	{
		m_state=PLAYING;
	}
	else
	{
		throw(CException(CException::SRC_SimpleAudioDevice,err,Pa_GetErrorText(err)));
	}*/

}

void CSimpleAudioOutStream::start() {
	// check the state of the object
	if(m_state==NOTREADY) // this is an error
	{
		CException myException(CException::SRC_SimpleAudioDevice, -1, "File not opened!\n");
		throw(myException);
	}
	else if(m_state==PLAYING)
		return;
	// now we can handle the READY state
	PaError err=Pa_StartStream(m_stream);
	if(err==paNoError)
	{
		cout<<"started\n";
		m_state=PLAYING;
	}
	else
	{
		CException myException(CException::SRC_SimpleAudioDevice, -1, "File not started!\n");
		throw(myException);
	}
	/*if( err == paNoError)
	{
		m_state=PLAYING;
	}
	else
	{
		throw(CException(CException::SRC_SimpleAudioDevice,err,Pa_GetErrorText(err)));
	}*/

}

void CSimpleAudioOutStream::close() {
	if(m_state==READY) // this is an error
	{
		PaError err=Pa_CloseStream(m_stream);
		if(err==paNoError)
			cout<<"closed stream\n";
		else
			cout<<"close stream not working\n";
		Pa_Terminate();
		m_state=NOTREADY;
	}
	else
	{
		CException myException(CException::SRC_SimpleAudioDevice, -1, "File cannot be closed!\n");
		throw(myException);
	}
}
