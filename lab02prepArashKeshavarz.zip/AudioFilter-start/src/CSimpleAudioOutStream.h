/*
 * CSimpleAudioOutStream.h
 *
 *  Created on: Nov 27, 2023
 *      Author: Arash Keshavarz Taromsari
 */

#ifndef CSIMPLEAUDIOOUTSTREAM_H_
#define CSIMPLEAUDIOOUTSTREAM_H_
#include "portaudio.h"
#include "CFile.h"
#include "CException.h"
//class initialisation
class CSimpleAudioOutStream {
public:
	enum STATES
	{
		NOTREADY,READY,PLAYING
	};
private:
	PaStream* m_stream;
	int m_numObj=0;
	STATES m_state;
public:
	CSimpleAudioOutStream();
	~CSimpleAudioOutStream();
	void start();
	void stop();
	void play(float* pBlock,int framesPerBlock);
	void resume();
	void pause();
	void open(int numChan, double fSample, unsigned long framesPerBuffer);
	void close();
};

#endif /* CSIMPLEAUDIOOUTSTREAM_H_ */
