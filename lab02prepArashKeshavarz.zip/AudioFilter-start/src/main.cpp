//Akhila Madhu
//1119180
/**
 * \file main.cpp
 * \brief main, test and auxiliary functions for ASDD Lab02 (AudioFilter)
 *
 * \date 05.01.21
 * \author A. Wirth <antje.wirth@h-da.de
 * \author H. Frank <holger.frank@h-da.de
 */
#include <wtypes.h>
#include <iostream>
#include <iomanip>
#include <cstring>
using namespace std;

#include <SKSLib.h>
#include "CFile.h"
#include "CFilter.h"
#include "portaudio.h"
//#include "CSoundFile.h"
#include "CSimpleAudioOutStream.h"

// insert include file for your audio stream class here

/**
 * horizontal divider for test list output
 */
string hDivider(80, '-');

// ******************* auxiliary functions for tests *******************
/**
 * \brief generates a stereo sine wave signal with 2 different frequencies
 *
 * \param pData pointer on data structure of type signalData
 * \param f1 frequency of left channel
 * \param f2 frequency of right channel
 */
bool getFilter(FILE *pFile, int fs, string &type, int &N, string &info,
		float *&bbuf, int &blen, float *&abuf, int &alen);
/**
 * \brief generates a stereo sine wave signal with 2 different frequencies
 */
void parseFilterFileTest(const string filename);

// ********* declarations of test functions (to be called in main) *********
// *****************
// preparatory tasks
// *****************
void Test_Prep02_FilterFileClassTest(const string &filename);
void Test_Prep03_AudioFilePlayTest(const string &soundfile);

// ****************
// laboratory tasks
// ****************
void Test_Lab01_SoundFilterPlayTest(string &soundfile, string &sndfile_w,
		string &fltfile);
void Test_Lab02_FilterOptimizeTest(string &soundfile, string &sndfile_w,
		float gFF, float gFB, int delay_ms);

// ********* main program **********************************************
int main(void) {
	// set stdout in non buffered mode
	setvbuf(stdout, NULL, _IONBF, 0);
	// Set console encoding to UTF-8
	SetConsoleOutputCP(CP_UTF8);

	cout << "AudioFilter started." << endl << endl;

	string sndname = "jazzyfrenchy";
	string sndf = ".\\files\\sounds\\" + sndname + ".wav";
	string fltf = ".\\files\\filters\\2000Hz_lowpass_Order6.txt";
	string sndfile_w=".\\files\\filtered_sounds\\" + sndname + ".wav";
	string fltfile=".\\files\\filters\\2000Hz_lowpass_Order6.txt";
	// try other filter files
	fltf=".\\files\\filters\\yulewalk_treble_boost_Order6.txt";
	fltfile=fltf;
	//fltf=".\\files\\basic_delay_16000_Order4001.txt";
	//fltf=".\\files\\basic_delay_feedback_16000_Order8001.txt";

	//parseFilterFileTest(fltf);
	Test_Prep02_FilterFileClassTest(fltf);

	Test_Prep03_AudioFilePlayTest(sndf);
	Test_Lab01_SoundFilterPlayTest(sndf,sndfile_w,fltfile);

	// *****************
	// preparatory tasks
	// *****************
	// cout << endl << hDivider << endl;
	// Test_Prep02_FilterFileClassTest(fltf);
	// cout << endl << hDivider << endl;
	// Test_Prep03_AudioFilePlayTest(sndf);
	// cout << endl << hDivider << endl;

	cout << endl << "AudioFilter finished." << endl << endl;
	return 0;
}

/**
 * \brief reads content of filter file and prints data of selected sample frequency
 *
 * Uses CFilterFile to read and print the special ASDD filter file format
 */
void Test_Prep02_FilterFileClassTest(const string &filename) {

	int fs1=16000,fs2=8000;
	int channels=2;
	//CFileBase cfb(filename,CFileBase::FILE_READ);
	CFilterFile cff(filename,CFileBase::FILE_READ);
	cff.open();
		if(cff.read(fs1))
		{
			//cff.getinfo();
			//cff.gettype();
			//cff.getOrder();
			//cff.getb();
			//cff.geta();
			//cff.getblen();
			//cff.getalen();
			cff.print();
			CFilter cf(cff.geta(),cff.getb(),cff.getOrder(),channels);
			//CFilter cf(cff.geta(),cff.getb(),cff.getOrder(),2);
		}
		else
			throw CException(CException::SRC_Filter, -1, "Filter coefficients not available!");
		cff.close();
}

/**
 * \brief plays audio file unfiltered
 *
 * same code as in Lab01 LabTask 01
 */
void Test_Prep03_AudioFilePlayTest(const string &soundfile) {
	cout << endl << hDivider << endl << __FUNCTION__ << " started." << endl
			<< endl;
	cout << endl << hDivider << endl << __FUNCTION__ << " started." << endl
			<< endl;
	CSimpleAudioOutStream c1;
	CSoundFile sf1(soundfile.c_str(), CSoundFile::FILE_READ);
	try {
		sf1.open();
		//int framesPerBlock=-4000;
		int framesPerBlock = sf1.getSampleRate() / 8;
		int sbufsize = sf1.getNumChannels() * framesPerBlock;
		float *sbuf = new float[sbufsize];
		c1.open(sf1.getNumChannels(), sf1.getSampleRate(), framesPerBlock);
		c1.start();
		int readsize;
		do {
			cout << "playing.. \n";
			//cout<<readsize;
			readsize = sf1.read(sbuf, sbufsize);
			c1.play(sbuf, readsize/sf1.getNumChannels());

		} while (framesPerBlock == readsize);
	}

	catch (CException &exception) {
		cout << "exception caught by AudioStreamPortAudioTest: " << endl;
		exception.print();
		return;


		cout << endl << __FUNCTION__ << " finished." << endl << hDivider << endl;
	}
}

/**
 * \brief plays filtered file
 *
 * \param soundfile name of audiofile to be played
 * \param sndfile_w name of soundfile the filtered data will be written in
 * \param fltfile name of filter file containing filter data
 */
void Test_Lab01_SoundFilterPlayTest(string &soundfile, string &sndfile_w,
		string &fltfile) {
	cout << endl << hDivider << endl << __FUNCTION__ << " started." << endl
			<< endl;

	try {
		CSimpleAudioOutStream c1;
		CSoundFile sf1(soundfile.c_str(), CSoundFile::FILE_READ);
		sf1.open();
		CSoundFile sf2(sndfile_w.c_str(),CFilterFile::FILE_WRITE);
		sf2.setFormat(sf1.getFormat());
		sf2.setNumChannels(sf1.getNumChannels());
		sf2.setSampleRate(sf1.getSampleRate());
		sf2.open();
		string type, info;
		//CFileBase cfb(filename,CFileBase::FILE_READ);
		CFilterFile cff(fltfile.c_str(),CFileBase::FILE_READ);
		cff.open();
		cff.read(sf2.getSampleRate());
		CFilter cf(cff.geta(),cff.getb(),cff.getOrder(),sf1.getNumChannels());
		int framesPerBlock = sf1.getSampleRate();
		int sbufsize = sf1.getNumChannels() * framesPerBlock;
		float *sbuf = new float[sbufsize];
		float *sbufiltered = new float[sbufsize];
		c1.open(sf1.getNumChannels(), sf1.getSampleRate(), framesPerBlock);
		c1.start();
		int readsize;
		do {
			cout << "playing.. \n";
			//cout<<readsize;
			readsize = sf1.read(sbuf, sbufsize);
			cf.filter(sbuf,sbufiltered,framesPerBlock);
			c1.play(sbufiltered, readsize/sf1.getNumChannels());
			sf2.write(sbufiltered,sbufsize);
		} while (framesPerBlock == readsize);
	}

	catch (CException &exception) {
		cout << "exception caught by AudioStreamPortAudioTest: " << endl;
		exception.print();
		return;
	}
	// todo insert implementation of lab task 1 here

	cout << endl << __FUNCTION__ << " finished." << endl << hDivider << endl;

}

/**
 * \brief plays file filtered by an optimized delay filter
 *
 * \param soundfile name of audiofile to be played
 * \param sndfile_w name of soundfile the filtered data will be written in
 * \param gFF forward gain
 * \param gFB backward gain
 * \param delay_ms delay time
 */
/*void Test_Lab02_FilterOptimizeTest(string &soundfile, string &sndfile_w,
		float gFF, float gFB, int delay_ms) {
}*/

/**
 * ASDD filter file parser
 * reads and returns the filter data from an ASDD filter file for given sampling frequency
 * Filter data are:
 * - coefficients (numerator & denominator)
 * - filter type
 * - filter order
 * - additional information provided in the filter file
 *
 *  (ASDD filter file format, see lesson Lab02 preparation for explanations)
 *
 * \param pFile file pointer of an open ASDD filter file
 * \param fs sampling frequency
 * \param type string reference to return the filter type
 * \param N integer reference to return the order
 * \param info string reference to return a filter description
 * \param bbuf pointer reference to return the numerator coefficients
 * \param blen integer reference to return the number of numerator coefficients
 * \param abuf pointer reference to return the denominator coefficients
 * \param alen integer reference to return the number of denominator coefficients
 * \return true if the filter data have been loaded into the appropriate parameters
 */
//
/*bool getFilter(FILE* pFile, int fs, string& type, int& N, string& info,
		float*& bbuf, int& blen, float*& abuf, int& alen) {
	if (pFile == NULL)
		return false;

	fseek(pFile, 0, SEEK_SET); // ensure to start at the beginning of the file

	// get the header
	int sbufsize = 360;
	char sbuf[sbufsize];
	fgets(sbuf, sbufsize, pFile);

	// parse the header
	string s = sbuf;
	N = 0; // order (number)
	int pos = 0, end = 0;
	end = s.find(";", pos);
	type = s.substr(pos, end - pos);
	pos = end + 1;
	end = s.find(";", pos);
	string sorder = s.substr(pos, end - pos);
	N = stoi(sorder);
	info = s.substr(end + 1);

	// read data
	int i, fsr;
	while ( NULL != fgets(sbuf, sbufsize, pFile)) {
		fsr = stoi(sbuf); // find fs
		if (fs != fsr) {
			char *pgot = sbuf;
			while (pgot) // skip b coefficients
			{
				pgot = fgets(sbuf, sbufsize, pFile);
				if (NULL != strrchr(sbuf, '\n'))
					break; // end of line has been read
			}
			while (pgot) // skip a coefficients
			{
				pgot = fgets(sbuf, sbufsize, pFile);
				if (NULL != strrchr(sbuf, '\n'))
					break;
			}
		} else {
			bbuf = new float[N + 1];
			abuf = new float[N + 1];
			char sep;
			for (i = 0; i < N + 1; i++) {
				if (EOF == fscanf(pFile, "%f%c", &bbuf[i], &sep))
					break;
				if (sep == '\n')
					break;
			}
			blen = i;
			if (sep != '\n')
				fscanf(pFile, "%c", &sep);
			for (i = 0; i < N + 1; i++) {
				if (EOF == fscanf(pFile, "%f%c", &abuf[i], &sep))
					break;
				if (sep == '\n')
					break;
			}
			alen = i;
			if (sep != '\n')
				fscanf(pFile, "%c", &sep);
			return true;
		}
	}
	return false;
}*/

/**
 * \brief test case function calling getFilter
 *
 * to be used for evaluating the projects environment
 */


/*void parseFilterFileTest(const string filename) {
	// open file
	FILE *pFile = fopen(filename.c_str(), "r");
	if (pFile == NULL) {
		cout << filename << ": file not found!" << endl;
		return;
	}

	int fs = 16000, order = 0, blen = 0, alen = 0;
	string type, info;
	float *b = NULL;
	float *a = NULL;
	bool bgot = getFilter(pFile, fs, type, order, info, b, blen, a, alen);

	cout << endl << "header: type=" << type << " Order=" << order << " Info="
			<< info << endl;

	cout << "fs=" << fs << endl;
	if (bgot && (a != NULL) && (b != NULL)) {
		cout << "b= " << fixed << setprecision(8);
		for (int i = 0; i < blen; i++)
			cout << b[i] << "\t";
		cout << endl << "a= ";
		for (int i = 0; i < alen; i++)
			cout << a[i] << "\t";
		cout << endl;
		delete[] b;
		delete[] a;
	} else
		cout << "No coefficients found for fs!" << endl;

	fclose(pFile);
}*/
